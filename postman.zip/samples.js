const scannedText =
  "PART NO 11 RH part name 11 minda test 11 140126 A 0151";


